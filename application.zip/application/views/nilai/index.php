<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="rounded mt-4 mb-3 p-4 bg-white shadow-lg ">
        <h1 class="h3 text-black"><?= $title; ?></h1>
    </div>

    <div class="rounded mt-4 mb-5 p-4 bg-white shadow-lg">
        <div class="row">
            <?php if ($user->id_profil != 3) : ?>
            <div class="col-md-12">
                <a class="mb-3 btn btn-outline-primary" href="<?= base_url('nilai/tambah'); ?>" role="button">
                    Tambah Nilai <i class="fa fa-plus"></i>
                </a>
            </div>
            <?php endif; ?>


        <?php if ($user->id_profil == 1) : ?>
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-hover table-bordered text-center w-100" id="tableExport">
                    <thead class="bg-primary text-white ">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama Siswa</th>
                            <th scope="col">Kelas</th>
                            <th scope="col">Mata Pelajaran</th>
                            <th scope="col">Tugas 1</th>
                            <th scope="col">Tugas 2</th>
                            <th scope="col">Tugas 3</th>
                            <th scope="col">PTS</th>
                            <th scope="col">PAS</th>
                            <th scope="col">NILAI AKHIR</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black">
                        <?php $i = 1; ?>
                        <?php foreach ($nilai as $u) : ?>
                        <?php $total = ($u->tgs_1 + $u->tgs_2 + $u->tgs_3 + $u->uas + $u->uts) / 5;  ?>
                            <tr>
                                <td scope="row"><?= $i; ?></td>
                                <td class="text-left"><?= $u->nis_siswa.' - '.$u->nama_siswa; ?></td>
                                <td class="text-left"><?= $u->kelas; ?></td>
                                <td class="text-left"><?= $u->nama_mapel; ?></td>
                                <td><?= $u->tgs_1; ?></td>
                                <td><?= $u->tgs_2; ?></td>
                                <td><?= $u->tgs_3; ?></td>
                                <td><?= $u->uts; ?></td>
                                <td><?= $u->uas; ?></td>
                                <td><?php if ($total <= '72' ) : ?>
                                    <span class="text-danger"><?= $total; ?></span></td>
                                <?php else : ?>
                                    <span><?= $total; ?></span></td>
                                <?php endif; ?>
                                <td class="text-nowrap">
                                    <a href="<?= base_url('nilai/ubah/' . $u->id_nilai); ?>" class="btn btn-outline-warning">
                                        <i class="fas fa-edit pop" data-toggle="popover" data-placement="bottom" data-content="Update"></i>
                                    </a>
                                    <a href="<?= base_url('nilai/hapus/' . $u->id_nilai); ?>" class="btn btn-outline-danger button-delete">
                                        <i class="fas fa-trash-alt pop" data-toggle="popover" data-placement="bottom" data-content="Delete"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php elseif ($user->id_profil != 1) : ?>
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-hover table-bordered text-center w-100" id="myTable">
                    <thead class="bg-primary text-white ">
                        <tr>
                            <th scope="col">#</th>
                            <?php if($user->id_profil == 2) : ?>
                            <th scope="col">Nama Siswa</th>
                            <th scope="col">Kelas</th>
                            <?php endif; ?>
                            <th scope="col">Mata Pelajaran</th>
                            <th scope="col">Tugas 1</th>
                            <th scope="col">Tugas 2</th>
                            <th scope="col">Tugas 3</th>
                            <th scope="col">PTS</th>
                            <th scope="col">PAS</th>
                            <th scope="col">NILAI AKHIR</th>
                            <?php if($user->id_profil == 2) : ?>
                            <th scope="col">ACTION</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody class="text-black">
                        <?php $i = 1; ?>
                        <?php foreach ($whereNilai as $wn) : ?>
                        <?php $total = ($wn->tgs_1 + $wn->tgs_2 + $wn->tgs_3 + $wn->uas + $wn->uts) / 5;  ?>
                            <tr>
                                <td scope="row"><?= $i; ?></td>
                                <?php if($user->id_profil == 2) : ?>
                                <td><?= $wn->nis_siswa .' - '.$wn->nama_siswa; ?></td>
                                <td><?= $wn->kelas; ?></td>
                                <?php endif; ?>
                                <td class="text-left"><?= $wn->nama_mapel; ?></td>
                                <td><?= $wn->tgs_1; ?></td>
                                <td><?= $wn->tgs_2; ?></td>
                                <td><?= $wn->tgs_3; ?></td>
                                <td><?= $wn->uts; ?></td>
                                <td><?= $wn->uas; ?></td>
                                <td><?php if ($total <= '72' ) : ?>
                                    <span class="text-danger"><?= $total; ?></span></td>
                                <?php else : ?>
                                    <span><?= $total; ?></span></td>
                                <?php endif; ?>
                                
                                <?php if($user->id_profil == 2) : ?>
                                <td class="text-nowrap">
                                    <a href="<?= base_url('nilai/ubah/' . $wn->id_nilai); ?>" class="btn btn-outline-warning">
                                        <i class="fas fa-edit pop" data-toggle="popover" data-placement="bottom" data-content="Update"></i>
                                    </a>
                                    <a href="<?= base_url('nilai/hapus/' . $wn->id_nilai); ?>" class="btn btn-outline-danger button-delete">
                                        <i class="fas fa-trash-alt pop" data-toggle="popover" data-placement="bottom" data-content="Delete"></i>
                                    </a>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>

    

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- modal -->
<!-- end modal -->

<?php require_once('application/views/templates/footer.php'); ?>

<!-- script -->
<!-- end script -->