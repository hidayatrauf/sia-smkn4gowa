<div class="row">
    <div class="col-md-12">
        <table class="h4 text-black table">
            <tr class="align-text-top">
                <td width="150px">Isi Saran </td>
                <td width="5px">:</td>
                <td class="font-weight-bold"><?= $saran->isi_saran; ?></td>
            </tr>
        </table>
    </div>
</div>